# sign language detection > 2025-05-26 2:03pm
https://universe.roboflow.com/project-3tx8e/sign-language-detection-wpzoh

Provided by a Roboflow user
License: CC BY 4.0

