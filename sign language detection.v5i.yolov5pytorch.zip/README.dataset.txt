# sign language detection > 2025-07-12 1:40am
https://universe.roboflow.com/project-3tx8e/sign-language-detection-wpzoh

Provided by a Roboflow user
License: CC BY 4.0

